alert('hi~~');
//document.write('hello!!');
var ok = confirm('Are you OK?');
alert(ok);
var name = prompt('What is your name?','no name');
alert(name);